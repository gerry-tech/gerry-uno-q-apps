int btn1 = 2;
int btn2 = 3;
int btn3 = 4;
int btn4 = 5;

int ledVerde = 9;
int ledRosso = 10;
int buzzer = 8;

int password = 4213;   // Change this number to change the order of the inputs (change password)
int input = 0;

void setup() {

  pinMode(btn1, INPUT_PULLUP);
  pinMode(btn2, INPUT_PULLUP);
  pinMode(btn3, INPUT_PULLUP);
  pinMode(btn4, INPUT_PULLUP);

  pinMode(ledVerde, OUTPUT);
  pinMode(ledRosso, OUTPUT);
  pinMode(buzzer, OUTPUT);
}

void loop() {

  if(digitalRead(btn1) == LOW){
    tone(buzzer, 1000, 100);  
    input = input * 10 + 1;
    delay(300);
  }

  if(digitalRead(btn2) == LOW){
    tone(buzzer, 1000, 100);
    input = input * 10 + 2;
    delay(300);
  }

  if(digitalRead(btn3) == LOW){
    tone(buzzer, 1000, 100);
    input = input * 10 + 3;
    delay(300);
  }

  if(digitalRead(btn4) == LOW){
    tone(buzzer, 1000, 100);
    input = input * 10 + 4;
    delay(300);
  }

  if(input > 999){   

    if(input == password){

      digitalWrite(ledVerde, HIGH);
      tone(buzzer, 1500);
      delay(3000);   

      digitalWrite(ledVerde, LOW);
      noTone(buzzer);

    }else{

      digitalWrite(ledRosso, HIGH);
      tone(buzzer, 200);
      delay(3000);   

      digitalWrite(ledRosso, LOW);
      noTone(buzzer);
    }

    input = 0;
  }

}
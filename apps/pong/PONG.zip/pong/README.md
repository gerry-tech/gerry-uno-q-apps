# 🎾 PONG

### Description

In quest'app ricreaiamo il famosissimo gioco PONG.
Nell'app sono preseti codici: C++, Python, JavaScript, CSS, HTML.

Se vuoi vedere come funziona guarda il mio video sul Canale!

# YT: Gerry&Tech


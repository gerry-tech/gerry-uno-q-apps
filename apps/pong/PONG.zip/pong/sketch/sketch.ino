#include <Arduino_RouterBridge.h>

const int led = 3;
const int buzzer = 8;

int valpot(){
  return analogRead(A0);
}

void win(){
  tone(buzzer, 1000);
  digitalWrite(led, HIGH);
}

void off(){
  noTone(buzzer);
  digitalWrite(led, LOW);
}

void setup() {
  // put your setup code here, to run once:
  Bridge.begin();
  pinMode(led, OUTPUT);
  pinMode(buzzer, OUTPUT);
  Bridge.provide("valpot", valpot);
  Bridge.provide("win", win);
  Bridge.provide("off", off);
}

void loop() {
  // put your main code here, to run repeatedly:

}

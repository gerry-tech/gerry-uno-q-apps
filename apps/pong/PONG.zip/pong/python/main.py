import os
from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.normpath(os.path.join(BASE_DIR, "..", "web"))

ui = WebUI(
    addr="0.0.0.0",
    port=7000,
    ui_path_prefix="",
    api_path_prefix="/api",
    assets_dir_path=ASSETS_DIR,
    use_tls=False,
)


def api_get_pot():
    try:
        value = int(Bridge.call("valpot"))
        return {"value": value}
    except Exception as e:
        return {"value": 0, "error": str(e)}


def api_reset_game():
    try:
        Bridge.call("off")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_player_win():
    try:
        Bridge.call("win")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


ui.expose_api("GET", "/pot", api_get_pot)
ui.expose_api("POST", "/reset", api_reset_game)
ui.expose_api("POST", "/win", api_player_win)

ui.start()

print("Web UI locale:", ui.local_url)
print("Web UI esterna:", ui.url)

App.run()

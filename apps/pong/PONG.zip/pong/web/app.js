const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const playerScoreEl = document.getElementById("playerScore");
const cpuScoreEl = document.getElementById("cpuScore");
const resetBtn = document.getElementById("resetBtn");
const statusText = document.getElementById("statusText");

let playerScore = 0;
let cpuScore = 0;
let lastPotValue = 0;
let gameStarted = false;
let lastWinTrigger = 0;
let lastPotReadOk = false;

const WIN_TRIGGER_COOLDOWN_MS = 700;
const paddleWidth = 12;
const paddleHeight = 100;
const ballSize = 14;

const player = {
  x: 20,
  y: canvas.height / 2 - paddleHeight / 2,
  width: paddleWidth,
  height: paddleHeight
};

const cpu = {
  x: canvas.width - 20 - paddleWidth,
  y: canvas.height / 2 - paddleHeight / 2,
  width: paddleWidth,
  height: paddleHeight,
  speed: 3.5
};

const ball = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  size: ballSize,
  speedX: 5,
  speedY: 3.2
};

function drawRect(x, y, w, h, color = "white") {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function drawBall() {
  ctx.fillStyle = "#00e5ff";
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.size / 2, 0, Math.PI * 2);
  ctx.fill();
}

function drawNet() {
  for (let i = 0; i < canvas.height; i += 30) {
    drawRect(canvas.width / 2 - 2, i, 4, 18, "white");
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawNet();
  drawRect(player.x, player.y, player.width, player.height, "#00ff99");
  drawRect(cpu.x, cpu.y, cpu.width, cpu.height, "#ff4444");
  drawBall();
}

function updateStatus(text, isError = false) {
  statusText.textContent = text;
  statusText.style.color = isError ? "#ff6666" : "#9fffd0";
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function resetBall(direction = null) {
  ball.x = canvas.width / 2;
  ball.y = canvas.height / 2;

  const dir = direction ?? (Math.random() > 0.5 ? 1 : -1);
  ball.speedX = dir * (4.8 + Math.random() * 1.2);
  ball.speedY = (Math.random() > 0.5 ? 1 : -1) * (2.5 + Math.random() * 2.2);
}

function bounceFromPaddle(paddle, isPlayer) {
  const relativeIntersectY = (ball.y - (paddle.y + paddle.height / 2)) / (paddle.height / 2);
  ball.speedY = relativeIntersectY * 5.5;

  const speedBoost = 0.35;
  const nextSpeedX = Math.abs(ball.speedX) + speedBoost;
  ball.speedX = isPlayer ? nextSpeedX : -nextSpeedX;

  ball.x = isPlayer
    ? paddle.x + paddle.width + ball.size / 2
    : paddle.x - ball.size / 2;
}

async function triggerWinEffect() {
  const now = Date.now();
  if (now - lastWinTrigger < WIN_TRIGGER_COOLDOWN_MS) return;
  lastWinTrigger = now;

  try {
    await fetch("/api/win", { method: "POST" });
  } catch (err) {
    console.log("Errore chiamata win:", err);
  }
}

async function turnOffEffects() {
  try {
    await fetch("/api/reset", { method: "POST" });
  } catch (err) {
    console.log("Errore reset API:", err);
  }
}

function handleScore(side) {
  if (side === "player") {
    playerScore++;
    playerScoreEl.textContent = playerScore;
    triggerWinEffect();
    resetBall(-1);
    updateStatus("Punto giocatore!");
  } else {
    cpuScore++;
    cpuScoreEl.textContent = cpuScore;
    turnOffEffects();
    resetBall(1);
    updateStatus("Punto CPU");
  }
}

function updateCpu() {
  const cpuCenter = cpu.y + cpu.height / 2;
  const target = ball.y;
  const delta = target - cpuCenter;

  if (Math.abs(delta) > cpu.speed) {
    cpu.y += Math.sign(delta) * cpu.speed;
  } else {
    cpu.y += delta;
  }

  cpu.y = clamp(cpu.y, 0, canvas.height - cpu.height);
}

function update() {
  ball.x += ball.speedX;
  ball.y += ball.speedY;

  if (ball.y - ball.size / 2 <= 0) {
    ball.y = ball.size / 2;
    ball.speedY *= -1;
  }

  if (ball.y + ball.size / 2 >= canvas.height) {
    ball.y = canvas.height - ball.size / 2;
    ball.speedY *= -1;
  }

  updateCpu();

  if (
    ball.x - ball.size / 2 <= player.x + player.width &&
    ball.x > player.x &&
    ball.y >= player.y &&
    ball.y <= player.y + player.height
  ) {
    bounceFromPaddle(player, true);
    turnOffEffects();
  }

  if (
    ball.x + ball.size / 2 >= cpu.x &&
    ball.x < cpu.x + cpu.width &&
    ball.y >= cpu.y &&
    ball.y <= cpu.y + cpu.height
  ) {
    bounceFromPaddle(cpu, false);
  }

  if (ball.x + ball.size < 0) {
    handleScore("cpu");
  }

  if (ball.x - ball.size > canvas.width) {
    handleScore("player");
  }
}

async function readPotValue() {
  try {
    const res = await fetch("/api/pot", { cache: "no-store" });
    const data = await res.json();
    const rawValue = Number(data.value);

    if (!Number.isFinite(rawValue)) {
      throw new Error("Valore potenziometro non valido");
    }

    lastPotValue = clamp(rawValue, 0, 1023);
    const mappedY = (lastPotValue / 1023) * (canvas.height - player.height);
    player.y = clamp(mappedY, 0, canvas.height - player.height);

    if (!lastPotReadOk) {
      updateStatus("Potenziometro collegato");
    }

    lastPotReadOk = true;
    gameStarted = true;
  } catch (err) {
    if (lastPotReadOk) {
      updateStatus("Errore lettura potenziometro", true);
    }
    lastPotReadOk = false;
    console.log("Errore lettura potenziometro:", err);
  }
}

async function gameLoop() {
  await readPotValue();
  if (gameStarted) {
    update();
  }
  draw();
  requestAnimationFrame(gameLoop);
}

resetBtn.addEventListener("click", async () => {
  playerScore = 0;
  cpuScore = 0;
  playerScoreEl.textContent = "0";
  cpuScoreEl.textContent = "0";
  resetBall();
  await turnOffEffects();
  updateStatus("Partita resettata");
});

resetBall();
draw();
gameLoop();

# 😀 LED RGB

### Description

In quest'app usiamo un led RGB per creare diverse gradazioni di colore tramite dei potenziometri (3)

1 per gestire il colore ROSSO
1 per gestire il colore VERDE
1 per gestire il colore BLU

# Se vuoi altri progetti iscriviti al canale : Gerry&Tech



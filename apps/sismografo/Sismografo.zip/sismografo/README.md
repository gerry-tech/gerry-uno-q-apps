# 😀 Sismografo

### Description


In quest'app si realizza un sismografo tramite una pagina web

# Guarda la demo su YT: Gerry&Tech


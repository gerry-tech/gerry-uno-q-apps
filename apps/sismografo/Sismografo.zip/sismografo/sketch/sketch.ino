#include <Wire.h>
#include <Arduino_RouterBridge.h>

#define MPU6050_ADDR 0x68
int BUZZER_PIN = 8;

float accelX = 0.0;
float accelY = 0.0;
float accelZ = 0.0;

float lastX = 0.0;
float lastY = 0.0;
float lastZ = 0.0;

float magnitude = 0.0;
float filteredMagnitude = 0.0;

bool alarmActive = false;

const float FILTER_ALPHA = 0.25;
const float ALERT_THRESHOLD = 0.08;
const unsigned long READ_INTERVAL = 40;

unsigned long lastRead = 0;

void writeMPU(byte reg, byte data) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  Wire.write(data);
  Wire.endTransmission();
}

int16_t read16(byte reg) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);

  Wire.requestFrom(MPU6050_ADDR, 2, true);
  int16_t value = (Wire.read() << 8) | Wire.read();
  return value;
}

void initMPU() {
  writeMPU(0x6B, 0x00); // wake up
  writeMPU(0x1C, 0x00); // accel ±2g
  writeMPU(0x1B, 0x00); // gyro ±250
  delay(100);
}

void updateBuzzer() {
  if (magnitude >= ALERT_THRESHOLD) {
    alarmActive = true;
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    alarmActive = false;
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void readMPU() {
  int16_t rawAx = read16(0x3B);
  int16_t rawAy = read16(0x3D);
  int16_t rawAz = read16(0x3F);

  float newX = rawAx / 16384.0;
  float newY = rawAy / 16384.0;
  float newZ = rawAz / 16384.0;

  float dx = newX - lastX;
  float dy = newY - lastY;
  float dz = newZ - lastZ;

  float rawMagnitude = sqrt(dx * dx + dy * dy + dz * dz);
  filteredMagnitude = FILTER_ALPHA * rawMagnitude + (1.0 - FILTER_ALPHA) * filteredMagnitude;

  accelX = newX;
  accelY = newY;
  accelZ = newZ;
  magnitude = filteredMagnitude;

  lastX = newX;
  lastY = newY;
  lastZ = newZ;

  updateBuzzer();
}

String getAccelX() {
  return String(accelX, 4);
}

String getAccelY() {
  return String(accelY, 4);
}

String getAccelZ() {
  return String(accelZ, 4);
}

String getMagnitude() {
  return String(magnitude, 4);
}

String getAlarmState() {
  return alarmActive ? "1" : "0";
}

String resetSeismo() {
  magnitude = 0.0;
  filteredMagnitude = 0.0;
  alarmActive = false;
  digitalWrite(BUZZER_PIN, LOW);
  return "ok";
}

void setup() {
  Wire.begin();

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  initMPU();

  Bridge.begin();

  Monitor.begin(9600);

  Bridge.provide("getAccelX", getAccelX);
  Bridge.provide("getAccelY", getAccelY);
  Bridge.provide("getAccelZ", getAccelZ);
  Bridge.provide("getMagnitude", getMagnitude);
  Bridge.provide("getAlarmState", getAlarmState);
  Bridge.provide("resetSeismo", resetSeismo);

  readMPU();
  delay(50);
  readMPU();

  Monitor.println("Sismografo pronto");
}

void loop() {
  if (millis() - lastRead >= READ_INTERVAL) {
    lastRead = millis();
    readMPU();
  }
}
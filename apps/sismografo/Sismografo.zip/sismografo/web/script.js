const statusEl = document.getElementById("status");
const alarmEl = document.getElementById("alarm");
const eventsEl = document.getElementById("events");
const xVal = document.getElementById("xVal");
const yVal = document.getElementById("yVal");
const zVal = document.getElementById("zVal");
const magVal = document.getElementById("magVal");
const resetBtn = document.getElementById("resetBtn");

const canvas = document.getElementById("chart");
const ctx = canvas.getContext("2d");

function drawChart(values) {
  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);

  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;

  for (let i = 0; i < 5; i++) {
    let y = (h / 4) * i;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  if (values.length === 0) return;

  let maxVal = 0.1;
  for (let v of values) {
    if (v > maxVal) maxVal = v;
  }

  ctx.strokeStyle = "#60a5fa";
  ctx.lineWidth = 2;
  ctx.beginPath();

  values.forEach((v, i) => {
    const x = (i / (values.length - 1 || 1)) * w;
    const y = h - (v / maxVal) * (h - 20) - 10;

    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });

  ctx.stroke();
}

function updateStatus(status) {
  statusEl.textContent = status;
  statusEl.className = "big";

  if (status === "CALMO") {
    statusEl.classList.add("status-calm");
  } else if (status === "MOVIMENTO") {
    statusEl.classList.add("status-move");
  } else {
    statusEl.classList.add("status-alert");
  }
}

function updateAlarm(alarm) {
  if (alarm === 1) {
    alarmEl.textContent = "ON";
    alarmEl.className = "big alarm-on";
  } else {
    alarmEl.textContent = "OFF";
    alarmEl.className = "big alarm-off";
  }
}

async function loadData() {
  try {
    const res = await fetch("/api/data");
    const data = await res.json();

    const s = data.state;
    const history = data.history;

    xVal.textContent = s.x.toFixed(4);
    yVal.textContent = s.y.toFixed(4);
    zVal.textContent = s.z.toFixed(4);
    magVal.textContent = s.magnitude.toFixed(4);
    eventsEl.textContent = s.events;

    updateStatus(s.status);
    updateAlarm(s.alarm);
    drawChart(history);
  } catch (e) {
    console.error("Errore:", e);
  }
}

resetBtn.addEventListener("click", async () => {
  try {
    await fetch("/api/reset");
  } catch (e) {
    console.error("Errore reset:", e);
  }
});

setInterval(loadData, 100);
loadData();
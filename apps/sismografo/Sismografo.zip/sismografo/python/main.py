import os
import time
import threading
from collections import deque

from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import Bridge, App

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.normpath(os.path.join(BASE_DIR, '..', 'web'))

ui = WebUI(
    addr='0.0.0.0',
    port=7000,
    ui_path_prefix='',
    api_path_prefix='/api',
    assets_dir_path=ASSETS_DIR,
    use_tls=False,
)

history = deque(maxlen=100)

state = {
    'x': 0.0,
    'y': 0.0,
    'z': 0.0,
    'magnitude': 0.0,
    'alarm': 0,
    'status': 'CALMO',
    'events': 0,
}

last_event_time = 0.0


def to_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def to_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def get_status(mag):
    if mag >= 0.08:
        return 'ALLERTA'
    if mag >= 0.03:
        return 'MOVIMENTO'
    return 'CALMO'


def read_sensor_loop():
    global last_event_time

    while True:
        try:
            x = to_float(Bridge.call('getAccelX'))
            y = to_float(Bridge.call('getAccelY'))
            z = to_float(Bridge.call('getAccelZ'))
            mag = to_float(Bridge.call('getMagnitude'))
            alarm = to_int(Bridge.call('getAlarmState'))

            status = get_status(mag)
            now = time.time()

            if alarm == 1 and (now - last_event_time) > 1:
                state['events'] += 1
                last_event_time = now

            state['x'] = round(x, 4)
            state['y'] = round(y, 4)
            state['z'] = round(z, 4)
            state['magnitude'] = round(mag, 4)
            state['alarm'] = alarm
            state['status'] = status

            history.append(round(mag, 4))
        except Exception as e:
            print('Errore lettura sensore:', e)

        time.sleep(0.1)


def api_data():
    return {
        'state': state,
        'history': list(history),
    }


def api_reset():
    state['events'] = 0
    history.clear()

    try:
        Bridge.call('resetSeismo')
    except Exception as e:
        return {'ok': False, 'error': str(e)}

    return {'ok': True}


ui.expose_api('GET', '/data', api_data)
ui.expose_api('GET', '/reset', api_reset)

threading.Thread(target=read_sensor_loop, daemon=True).start()

ui.start()
print('Web UI locale:', ui.local_url)
print('Web UI esterna:', ui.url)

App.run()

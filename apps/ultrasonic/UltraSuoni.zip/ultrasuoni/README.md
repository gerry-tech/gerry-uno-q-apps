# 😀 UltraSuoni

### Description

In quest'app sfruttiamo un sensore ad ultra suoni che calcola la distanza di oggetti di fronte ad esso.
Il sensore è montato sopra un Servo Motore, che ruotando ruota il sensore.
### Se vuoi vedere la demo guarda il mio video sul canale : Gerry&Tech



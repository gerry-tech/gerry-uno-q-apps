#include <Arduino_RouterBridge.h>
#include <Servo.h>

Servo myservo;

const int trigPin = 9;
const int echoPin = 10;
const int servoPin = 3;

int grado = 0;
int direzione = 1;  // 1 = avanti, -1 = indietro

unsigned long lastServoMillis = 0;
unsigned long lastUltraMillis = 0;

void setup() {
  Bridge.begin();
  Monitor.begin(9600);

  myservo.attach(servoPin);

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

void loop() {
  servo();
  ultra();
}

void servo() {
  if (millis() - lastServoMillis >= 50) {
    lastServoMillis = millis();

    myservo.write(grado);
    grado += direzione;

    if (grado >= 180) {
      grado = 180;
      direzione = -1;
    }

    if (grado <= 0) {
      grado = 0;
      direzione = 1;
    }
  }
}

void ultra() {
  if (millis() - lastUltraMillis >= 200) {
    lastUltraMillis = millis();

    long durata;
    float distanza;

    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);

    durata = pulseIn(echoPin, HIGH, 30000);

    if (durata == 0) {
      Monitor.println("Fuori portata o nessun segnale");
    } else {
      distanza = durata * 0.0343 / 2.0;

      Monitor.print("Distanza: ");
      Monitor.print(distanza);
      Monitor.println(" cm");
    }
  }
}
# 😀 mpu6050

### Description

In quest'app sfruttiamo un MPU6050 per leggere gli assi in cui viene inclinato il sensore e in base a dove viene inclinato disegna nel led matrix un freccia corrispondente alla direzione.

# Demo sul canale YT: Gerry&Tech



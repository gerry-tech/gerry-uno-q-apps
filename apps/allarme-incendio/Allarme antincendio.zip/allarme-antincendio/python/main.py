import time
from arduino.app_utils import App, Bridge

def loop():
    try:
        t = Bridge.call("temperatura", timeout=2)
        raw = Bridge.call("temperatura_raw", timeout=2)
        print("T =", t, " | RAW =", raw)
    except TimeoutError:
        print("⚠️ timeout (ritento...)")
    time.sleep(0.5)

App.run(user_loop=loop)
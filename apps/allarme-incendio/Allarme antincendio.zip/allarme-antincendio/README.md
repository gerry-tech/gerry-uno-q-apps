# 😀 Allarme antincendio

### Description

In quest'app viene creato un Allarme Anti Incendio;

# Se volete vedere altri contenuti, andatemi a seguire su YT: Gerry&Tech


